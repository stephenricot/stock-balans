-- ============================================================
-- Migration: performance indexes + low-stock alert cron job
-- ============================================================

-- 1. Indexes missing from initial schema
--    These make server-side search & category filter fast at scale.
CREATE INDEX IF NOT EXISTS inventory_business_name_idx
  ON public.inventory (business_id, name);

CREATE INDEX IF NOT EXISTS inventory_business_category_idx
  ON public.inventory (business_id, category)
  WHERE category IS NOT NULL;

-- 2. Add CHECK constraints that were missing
ALTER TABLE public.inventory
  ADD CONSTRAINT inventory_quantity_non_negative
    CHECK (quantity >= 0);

ALTER TABLE public.inventory
  ADD CONSTRAINT inventory_reorder_point_non_negative
    CHECK (reorder_point >= 0);

ALTER TABLE public.user_profiles
  ADD CONSTRAINT user_profiles_role_valid
    CHECK (role IN ('user-supplier', 'admin', 'super-admin'));

-- 3. Schedule the low-stock alert Edge Function via pg_cron
--    Runs every day at 08:00 UTC (adjust to your timezone).
--    Requires the pg_cron extension — enable it in:
--    Supabase Dashboard → Database → Extensions → pg_cron
--
--    The function URL format:  https://<project-ref>.supabase.co/functions/v1/low-stock-alerts
--    Replace <project-ref> with your actual project reference.

SELECT cron.schedule(
  'low-stock-alerts-daily',                          -- job name (unique)
  '0 8 * * *',                                       -- cron expression: 8am UTC daily
  $$
    SELECT net.http_post(
      url     := current_setting('app.supabase_url') || '/functions/v1/low-stock-alerts',
      headers := jsonb_build_object(
        'Content-Type',  'application/json',
        'Authorization', 'Bearer ' || current_setting('app.service_role_key')
      ),
      body    := '{}'::jsonb
    );
  $$
);

-- NOTE: After running this migration, set these Postgres settings in
-- Supabase Dashboard → Database → Settings → Custom Config (or via SQL):
--
--   ALTER DATABASE postgres SET app.supabase_url = 'https://<project-ref>.supabase.co';
--   ALTER DATABASE postgres SET app.service_role_key = '<your-service-role-key>';
--
-- These are server-side only and never exposed to clients.
